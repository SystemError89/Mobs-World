-- Team Bimbam

--	TB


--	Baby (normal)
mobs:register_mob("mobs_melmel:mmTBba", {
	type = "tb",
	passive = false,
	attack_type = "dogfight",
	attack_tas = true,
    --if pathfinding is set to false then bigbaby cant jump - when chasing you
    --pathfinding = true,
	damage = 3,
	hp_min = 12,
	hp_max = 35,
	armor = 150,
    reach = 2.5,
    --if you put fifth 5th number higher than 2.3 and stepheight is lowwer than 1.2 then the creep starts glitching throught thi ground
    collisionbox = {-0.5, -0.01, -0.5, 0.5, 0.41, 0.5},
    --with this collisionbox, stepheight lower than 1.2 and pathfinding set to 1 bigbaby glitches into the ground also turns black
    --collisionbox = {-2, -0.01, -2, 2, 2.91, 2},
	visual = "mesh",
	mesh = "amcaw_baby.b3d",
	textures = {
		{"TB_ba.png"},
	},
	visual_size = {x=1.6, y=1.6},
	rotate = -180,
--	makes_footstep_sound = true,
--	sounds = {
--		random = "amcaw_bigbaby",
--		damage = "amcaw_bigbabyhurt1",
--	},
	walk_velocity = 0.2,
	run_velocity = 0.6,
	jump = true,
	stepheight = 0.2,
    jump_height = 0.6,
	floats = 0,
	view_range = 8,
    --superbabyfood should be a bit rare maybe 1 every two kills
--	drops = {
--		{name = "amcaw:super_baby_food",
--		chance = 2, min = 0, max = 1,},
--	},
	water_damage = 5,
    fear_height = 6,
	lava_damage = 7,
	light_damage = 0,
	fall_damage = 8,
	animation = {
		speed_normal = 6,		speed_run = 12,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,			walk_end = 40,
		run_start = 0,			run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
	do_custom = function(self)
		if self.state == "attack" then
			self.float = 1
			self.fall_speed = -4
			
			local pos = self.object:get_pos()
			
			pos.x = pos.x
			pos.y = pos.y
			pos.z = pos.z
			
			self.object:set_pos({x = pos.x, y = pos.y + 0.05, z = pos.z})
		end
	end,
	on_die = function(self)
		local pos = self.object:getpos()
		pos.y = pos.y + 1
		minetest.add_entity(pos, "mobs_melmel:mmTBbb")
	end,
})

local function is_night()
	return minetest.get_timeofday() < 0.2 or minetest.get_timeofday() > 0.76
end

local function is_bti()
	return minetest.get_timeofday() < 0.24 or minetest.get_timeofday() > 0.2
end

local function is_cti()
	return minetest.get_timeofday() < 0.3 or minetest.get_timeofday() > 0.25
end

local function is_dti()
	return minetest.get_timeofday() > 0.31 or minetest.get_timeofday() < 0.37
end

local function is_eti()
	return minetest.get_timeofday() > 0.38 or minetest.get_timeofday() < 0.46
end

local function is_fti()
	return minetest.get_timeofday() > 0.48 or minetest.get_timeofday() < 0.75
end

--	Baby (big)
mobs:register_mob("mobs_melmel:mmTBbb", {
	type = "tb",
	passive = false,
	attack_type = "dogfight",
	attacks_monsters = true,
    --if pathfinding is set to false then bigbaby cant jump - when chasing you
    --pathfinding = true,
    stepheight = 1.2,
	damage = 8,
	hp_min = 12,
	hp_max = 70,
	armor = 50,
    reach = 2.5,
    --if you put fifth 5th number higher than 2.3 and stepheight is lowwer than 1.2 then the creep starts glitching throught thi ground
    collisionbox = {-1, -0.01, -1, 1, 1.91, 1},
    --with this collisionbox, stepheight lower than 1.2 and pathfinding set to 1 bigbaby glitches into the ground also turns black
    --collisionbox = {-2, -0.01, -2, 2, 2.91, 2},
	visual = "mesh",
	mesh = "amcaw_baby.b3d",
	textures = {
		{"TB_ba.png"},
	},
	visual_size = {x=12, y=12},
	rotate = -180,
--	makes_footstep_sound = true,
--	sounds = {
--		random = "amcaw_bigbaby",
--		damage = "amcaw_bigbabyhurt1",
--	},
	walk_velocity = 1,
	run_velocity = 2,
	jump = true,
    jump_height = 6,
	view_range = 10,
    --superbabyfood should be a bit rare maybe 1 every two kills
--	drops = {
--		{name = "amcaw:super_baby_food",
--		chance = 2, min = 0, max = 1,},
--	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	do_custom = function(self, dtime)

		if is_night() then
			self.object:set_pos({x = 1, y = 20, z = 0})
		elseif is_cti() then
			local pos = self.object:get_pos()
			local blu = {
					{name = "default:pork_raw",
					chance = 2, min = 1, max = 10,},
					{name = "default:apple",
					chance = 3, min = 1, max = 10,},
					{name = "default:stick",
					chance = 4, min = 1, max = 10,},
					{name = "mobs:egg",
					chance = 5, min = 1, max = 10,},
					{name = "farming:bread",
					chance = 6, min = 1, max = 10,},
				}

			minetest.add_item(pos, blu)

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 4,
			})
		elseif is_bti() then
			local pos = self.object:get_pos()

			{minetest.add_item(pos, "mobs:egg"),
			chance = 3, min = 1, max = 5,},
			{minetest.add_item(pos, "default:apple"),
			chance = 4, min = 1, max = 5,},

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 4,
			})
		elseif is_dti() then
			local pos = self.object:get_pos()

			chance = 3
			minetest.add_item(pos, "farming:bread")

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 4,
			})
		elseif is_eti() then
			local pos = self.object:get_pos()
	
			minetest.add_item(pos, "default:apple")

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 4,
			})
		elseif is_fti() then
			local pos = self.object:get_pos()
	
			minetest.add_item(pos, "default:stick")

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 4,
			})
		else
			self.apple_timer = (self.apple_timer or 0) + dtime
			if self.apple_timer < 10 then
				return
			end
			self.apple_timer = 0

			if self.child
			or math.random(1, 100) > 1 then
				return
			end

			local pos = self.object:get_pos()
	
			minetest.add_item(pos, "default:apple")

			minetest.sound_play("default_place_node_hard", {
				pos = pos,
				gain = 1.0,
				max_hear_distance = 5,
			})
		end
	end,
	animation = {
		speed_normal = 25,		speed_run = 30,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
--		punch_start = 168,		punch_end = 188,
	},
	on_die = function(self)
		local pos = self.object:get_pos()

		minetest.add_item(pos, "mobs:egg")

		minetest.sound_play("default_place_node_hard", {
			pos = pos,
			gain = 1.0,
			max_hear_distance = 5,
		})
	end,
})

--	J.Bo
mobs:register_mob("mobs_melmel:mmTBja", {
	type = "tb",
	passive = false,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 2, -- shoot for 10 seconds
	dogshoot_count2_max = 8, -- dogfight for 3 seconds
	shoot_interval = 2,
	arrow = "mobs_stoneage:spearst",
	shoot_offset = 1.7,
    pathfinding = true,
	damage = 3,
	hp_min = 22,
	hp_max = 44,
	armor = 90,
	reach = 1,
	attacks_tas = true,
    collisionbox = {-0.2,-0.45,-0.2, 0.2,0.4,0.2},
	visual = "mesh",
	mesh = "amcaw_character.b3d",
	textures = {
		{"TB_ja.png"},
	},
	visual_size = {x=0.35, y=0.4},
--	makes_footstep_sound = true,
--	sounds = {
--		random = "amcaw_kid",
        --sound kid is cold?
--		damage = "amcaw_kidhurt",
		--attack = "abc",
--		death = "amcaw_kiddeath",
--	},
	walk_velocity = 1,
	run_velocity = 1.5,
	jump = true,
	floats = 1,
	view_range = 12,
	runaway = true,
	drops = {
		{name = "default:pork_raw",
		chance = 2, min = 1, max = 5,},
	},
	water_damage = 0,
    fear_height = 6,
	lava_damage = 1,
	light_damage = 0,
	do_custom = function(self, dtime)

		self.egg_timer = (self.egg_timer or 0) + dtime
		if self.egg_timer < 10 then
			return
		end
		self.egg_timer = 0

		if self.child
		or math.random(1, 100) > 1 then
			return
		end

		local pos = self.object:get_pos()

		minetest.add_item(pos, "mobs:egg")

		minetest.sound_play("default_place_node_hard", {
			pos = pos,
			gain = 1.0,
			max_hear_distance = 5,
		})
	end,
	animation = {
		speed_normal = 10,		speed_run = 15,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 188,
		run_start = 168,		run_end = 188,
		punch_start = 168,		punch_end = 188,
	},
})

-- Cave Hunter
mobs:register_mob("mobs_melmel:mmTBh", {
	-- animal, monster, npc
	name = "mmTBh",
	type = "ta", "npc",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "throw_spear",
	dogshoot_switch = 1,
	dogshoot_count_max = 2, -- shoot for 10 seconds
	dogshoot_count2_max = 13, -- dogfight for 3 seconds
	shoot_interval = 1.5,
	arrow = "mobs_stoneage:spearst",
	shoot_offset = 2.5,
	attacks_npcs = false,
	attack_animals = true,
	attack_armyas = false,
	attack_tas = false,
	attack_armybs = true,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	attack_evils = true,
	group_attack = true,
	peaceful = true,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 20, hp_max = 30, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TA_ch1.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:spearst"].inventory_image,},
--		{"TA_ch2.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:spearst"].inventory_image,},
--		{"TA_ch3.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:spearst"].inventory_image,},
		{"TA_ch4.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:spearst"].inventory_image,}
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = .5,
	run_velocity = 3.5,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 18,
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 35,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 211,		shoot_end = 215,
	},
})


-- ninja spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)


mobs:register_egg("mobs_melmel:mmTBba", "Baby (mmTB)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTBbb", "Baby (big) (mmTB)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTBja", "J.Bo (mmTB)", "default_leaves.png", 1)
--	mobs:register_egg("mobs_melmel:mmTBh", "Cave Hunter (mmTB)", "default_leaves.png", 1)