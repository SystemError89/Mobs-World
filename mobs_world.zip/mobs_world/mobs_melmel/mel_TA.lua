-- Ruby Kingdom

--	A


-- Queen MM
mobs:register_mob("mobs_melmel:mmTAq", {
	name = "mmTAq",
	type = "ta", "npc",
	knock_back = .5,
	damage = 4,
	attack_type = "dogfight",
	reach = 2,
	attack_armyas = false,
	attack_tas = false,
	attack_armybs = true,
	attacks_tbs = true,
	attack_armycs = false,
	attacks_tcs = false,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	attack_evils = true,
	group_attack = false,
	peaceful = true,
	passive = false,
	pathfinding = true,
	hp_min = 20, hp_max = 33, armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TA_q.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
	},
	visual_size = {x=1.1, y=1.1},
	makes_footstep_sound = true,
	sounds = {},
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	water_damage = 4,
	lava_damage = 7,
	light_damage = 0,
	fall_damage = 8,
	view_range = 18,
	on_die = function(self)
		local pos = self.object:getpos()
		pos.y = pos.y + 1
		minetest.add_entity(pos, "mobs_melmel:mmTAqh")
	end,
	animation = {
		speed_normal = 20,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	Queen Mel
mobs:register_mob("mobs_melmel:mmTAqb", {
	type = "ta",
	hp_min = 26,
	hp_max = 26,
	collisionbox = {-0.3, -0.01, -0.3, 0.3, 1.94, 0.3},
	visual = "mesh",
	mesh = "mobs_mc_witch.b3d",
	textures = {
		{"TA_q2.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	damage = 2,
	reach = 2,
	walk_velocity = 1.2,
	run_velocity = 2.4,
	pathfinding = 1,
	group_attack = true,
	attack_type = "dogshoot",
	arrow = "mobs:arrow",
	shoot_interval = 2.5,
	shoot_offset = 1,
	dogshoot_switch = 1,
	dogshoot_count_max =1.8,
	max_drops = 3,
	drops = {
		{name = "default:apple", chance = 8, min = 0, max = 2,},
--		{name = mobs_mc.items.glowstone_dust, chance = 8, min = 0, max = 2,},
	},
--	sounds = {
--		random = "Villager1",
--		death = "Villagerdead",
--		damage = "Villagerhurt1",
--		distance = 16,
--	},
	animation = {
		speed_normal = 30,	speed_run = 60,
		stand_start = 0,	stand_end = 0,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
		hurt_start = 85,	hurt_end = 115,
		death_start = 117,	death_end = 145,
		shoot_start = 50,	shoot_end = 82,
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	view_range = 16,
	fear_height = 4,
})

--	Melhellbaroness
mobs:register_mob("mobs_melmel:mmTAqh", {
   type = "ta",
   passive = false,
   attacks_tcs = true,
   damage = 3,
   reach = 2,
   attack_type = "dogshoot",
   shoot_interval = 2.5,
	dogshoot_switch = 2,
	dogshoot_count = 0,
	dogshoot_count_max =5,
   arrow = "mobs_stoneage:stone",
   shoot_offset = 0.5,
   hp_min = 40,
   hp_max = 55,
   armor = 80,
   collisionbox = {-0.5, 0, -0.6, 0.6, 3, 0.6},
   visual = "mesh",
   mesh = "hellbaron.b3d",
   textures = {
      {"TA_qh.png"},
   },
   blood_amount = 80,
   blood_texture = "horror_blood_effect.png",
   visual_size = {x=1, y=1},
   makes_footstep_sound = true,
   walk_velocity = 2,
   run_velocity = 3.5,
   jump = true,
   drops = {
      {name = "default:steel_ingot", chance = 1, min = 1, max = 5},
   },
   water_damage = 4,
   lava_damage = 2,
   light_damage = 2,
   fall_damage = 5,
   view_range = 20,
   on_die = function(self)
		local pos = self.object:getpos()
		pos.y = pos.y + 1
		minetest.add_entity(pos, "mobs_melmel:mmTAqd")
	end,
   animation = {
      speed_normal = 10,
      speed_run = 20,
      walk_start = 51,
      walk_end = 75,
      stand_start = 1,
      stand_end = 25,
      run_start = 51,
      run_end = 75,
      punch_start = 25,
      punch_end = 50,
	  shoot_start = 25,
	  shoot_end = 50,
   },
})

-- Meldragon
mobs:register_mob("mobs_melmel:mmTAqd", {
	type = "ta",
	passive = false,
	attacks_tcs = true,
	damage = 8,
	reach = 3,
	attack_type = "dogshoot",
	shoot_interval = 3.5,
	arrow = "mobs_stoneage:stone",
	shoot_offset = 1.4,
	hp_min = 50,
	hp_max = 85,
	armor = 90,
	collisionbox = {-0.6, -0.9, -0.6, 0.6, 0.6, 0.6},
	visual = "mesh",
	mesh = "dragon_new.b3d",
	textures = {
      {"TA_qd.png"},
	},
	blood_amount = 90,
	blood_texture = "horror_blood_effect.png",
	visual_size = {x=2.8, y=2.8},
	makes_footstep_sound = true,
--	sounds = {
--		shoot_attack = "mobs_fireball",
--	},
	pathfinding = true,
	walk_velocity = 3,
	run_velocity = 5,
	jump = true,
	fly = true,
	fly_in = "air",
	drops = {
	    {name = "mobs:lava_orb", chance = 2, min = 1, max = 3},
		{name = "default:diamond", chance = 2, min = 1, max = 3},
	},
	fall_speed = 0,
	stepheight = 1.6,
	jump_height = 4.5,
	water_damage = 6,
	lava_damage = 1,
	light_damage = 0,
	fall_damage = 1,
	view_range = 20,
	on_die = function(self)
		local pos = self.object:getpos()
		pos.y = pos.y + 1
		minetest.add_entity(pos, "mobs_melmel:mmTAqe")
	end,
	animation = {
		speed_normal = 10,
		speed_run = 20,
		walk_start = 1,
		walk_end = 22,
		stand_start = 1,
		stand_end = 22,
		run_start = 1,
		run_end = 22,
		punch_start = 21,
		punch_end = 47,
	},
})

-- Mel Dragon A
mobs:register_mob("mobs_melmel:mmTAqe", {
	type = "ta",
	hp_max = 60,
	hp_min = 60,
	collisionbox = {-0.65, -0.4, -0.65, 0.65, 0.4, 0.65},
	visual = "mesh",
	mesh = "moonherontrio.x",
	textures = {{"moonherontrio.png"}},
	visual_size = {x=18, y=18},
	view_range = 40,
	rotate = 270,
	lifetimer = 500,
	floats=1,
	walk_velocity = 3,
	run_velocity = 4,
	fall_speed = 0,
	stepheight = 3,
	sounds = {
		random = "night_master",
		distance = 45,
	},
	damage = 10,
	jump = false,
	armor = 60,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	blood_texture="nssm_blood.png",
	blood_amount=50,
	on_rightclick = nil,
	fly = true,
	attack_type = "dogfight",
	attacks_tcs = true,
	animation = {
		speed_normal = 25,
		speed_run = 35,
		stand_start = 60,
		stand_end = 120,
		walk_start = 20,
		walk_end = 50,
		run_start = 20,
		run_end = 50,
		punch_start = 130,
		punch_end = 160,
	},
	do_custom = function(self)
		if self.state == "attack" then
			self.fly = false
			self.fall_speed = -4
		end
	end,
	on_die = function(self, pos)
		minetest.add_particlespawner(
			200, --amount
			0.1, --time
			{x=pos.x-1, y=pos.y-1, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y+1, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=1, y=1, z=1}, --maxvel
			{x=-0.5,y=5,z=-0.5}, --minacc
			{x=0.5,y=5,z=0.5}, --maxacc
			0.1, --minexptime
			1, --maxexptime
			3, --minsize
			4, --maxsize
			false, --collisiondetection
			"tnt_smoke.png" --texture
		)
		self.object:remove()
		minetest.add_entity(pos, "mobs_melmel:mmTAqf")
	end,
})

-- Mel Dragon B
mobs:register_mob("mobs_melmel:mmTAqf", {
	type = "ta",
	hp_max = 60,
	hp_min = 60,
	collisionbox = {-0.65, -0.4, -0.65, 0.65, 0.4, 0.65},
	visual = "mesh",
	mesh = "night_master_2.x",
	textures = {{"moonherontrio.png"}},
	visual_size = {x=18, y=18},
	view_range = 40,
	rotate = 270,
	lifetimer = 500,
	floats=1,
	walk_velocity = 3,
	run_velocity = 4,
	fall_speed = 0,
	stepheight = 3,
	sounds = {
		random = "night_master",
		distance = 45,
	},
	damage = 10,
	jump = false,
	armor = 60,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
  	fly = true,
	attack_type = "dogfight",
	attacks_tcs = true,
	animation = {
		speed_normal = 25,
		speed_run = 35,
		stand_start = 60,
		stand_end = 120,
		walk_start = 20,
		walk_end = 50,
		run_start = 20,
		run_end = 50,
		punch_start = 130,
		punch_end = 160,
	},
	on_die = function(self, pos)
		minetest.add_particlespawner(
			200, --amount
			0.1, --time
			{x=pos.x-1, y=pos.y-1, z=pos.z-1}, --minpos
			{x=pos.x+1, y=pos.y+1, z=pos.z+1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=1, y=1, z=1}, --maxvel
			{x=-0.5,y=5,z=-0.5}, --minacc
			{x=0.5,y=5,z=0.5}, --maxacc
			0.1, --minexptime
			1, --maxexptime
			3, --minsize
			4, --maxsize
			false, --collisiondetection
			"tnt_smoke.png" --texture
		)
		self.object:remove()
		minetest.add_entity(pos, "mobs_melmel:mmTAqg")
	end,
})

-- Mel Dragon C
mobs:register_mob("mobs_melmel:mmTAqg", {
	type = "ta",
	hp_max = 70,
	hp_min = 70,
	collisionbox = {-0.65, -0.4, -0.65, 0.65, 0.4, 0.65},
	visual = "mesh",
	mesh = "night_master_1.x",
	textures = {{"moonherontrio.png"}},
	visual_size = {x=18, y=18},
	view_range = 40,
	rotate = 270,
	lifetimer = 500,
	floats=1,
	walk_velocity = 3,
	run_velocity = 4,
	fall_speed = 0,
	stepheight = 3,
	sounds = {
		random = "night_master",
		distance = 45,
	},
	damage = 12,
	jump = false,
	drops = {
		{name = "default:apple",
		chance = 1,
		min = 6,
		max = 7,},
	},
	armor = 50,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	fly = true,
	attack_type = "dogfight",
	attacks_tcs = true,
	animation = {
		speed_normal = 25,
		speed_run = 35,
		stand_start = 60,
		stand_end = 120,
		walk_start = 20,
		walk_end = 50,
		run_start = 20,
		run_end = 50,
		punch_start = 130,
		punch_end = 160,
	},
	do_custom = function(self)
		if self.state == "attack" then
			self.fly = false
			self_float = true
			self.fall_speed = 0.1
		end
	end,
	on_die = function(self)
		local pos = self.object:getpos()
		pos.y = pos.y + 1
		minetest.add_entity(pos, "mobs_melmel:mmTAqb")
	end
})


-- ninja spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_melmel:mmTAq", "Queen Melissa (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqb", "Queen Melissa2 (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqh", "Mel Baroness (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqd", "Mel Dragon (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqe", "Mel Dragon2 (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqf", "Mel Dragon3 (mmTA)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTAqg", "Mel Dragon4 (mmTA)", "default_leaves.png", 1)