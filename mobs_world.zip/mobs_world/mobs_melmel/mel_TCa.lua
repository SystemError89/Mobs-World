-- Candy Kingdom

--	Guards


--	Banana Guard
mobs:register_mob("mobs_melmel:mmTCbg", {
	type = "tc", "npc",
	hp_min = 30,
	hp_max = 30,
    	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	view_range = 16,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 6,
	reach = 3,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"TC_bg.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
	},
	visual_size = {x=1, y=1},
--	sounds = {
--		damage = "mobs_mc_squid_hurt",
--		distance = 16,
--	},
	animation = {
		stand_speed = 25, 	walk_speed = 20, 	run_speed = 30,
		stand_start = 0,	stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
	},
	drops = {
		{name = "farming:bread",
		chance = 1,	min = 0,	max = 2,},
	},
	fly = false,
--	fly_in = { mobs_mc.items.water_source, mobs_mc.items.river_water_source },
--	stepheight = 0.1,
	jump = true,
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	blood_amount = 0,
})

--	Candy Guard
mobs:register_mob("mobs_melmel:mmTCcg", {
	type = "tc",
	passive = false,
	attacks_monsters = true,
	reach = 1,
	damage = 2,
	attack_type = "dogfight",
	hp_min = 22,
	hp_max = 32,
	armor = 80,
--	shoot_interval = 1.5,
--	arrow = "scifi_mobs:blaser",
--	shoot_offset = -1,
	collisionbox = {-1, 0, -1, 1, 10, 1},
--	sounds = {
--	  shoot_attack = "Laser",
--	},
	visual = "mesh",
	mesh = "irongiant.b3d",
	textures = {
		{"TC_cg.png"},
	},
	visual_size = {x=4, y=4},
	makes_footstep_sound = false,
	walk_velocity = 1,
	run_velocity = 2,
	jump = false,
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	view_range = 14,
	animation = {
		speed_normal = 8,
		speed_run = 8,
		walk_start = 1,
		walk_end = 40,
		stand_start = 1,
		stand_end = 1,
		run_start = 1,
		run_end = 40,
		shoot_start = 40,
		shoot_end = 60,
	},
})


-- ninja spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)


mobs:register_egg("mobs_melmel:mmTCbg", "Banana Guard (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCcg", "Candy Guard (mmTC)", "default_leaves.png", 1)
--	mobs:register_egg("mobs_melmel:mmTCnc", "Nyan Cat (mmTC)", "default_leaves.png", 1)