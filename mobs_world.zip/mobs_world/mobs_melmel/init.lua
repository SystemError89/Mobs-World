--mobs_badplayer v1.4
--maikerumine
--made for Extreme Survival game
--License for code WTFPL


local path = minetest.get_modpath("mobs_melmel")

-- Intllib
local S
if minetest.global_exists("intllib") then
	if intllib.make_gettext_pair then
		-- New method using gettext.
		S = intllib.make_gettext_pair()
	else
		-- Old method using text files.
		S = intllib.Getter()
	end
else
	S = function(s) return s end
end
mobs.intllib = S


--	crafts, weapons, etc
--	dofile(path .. "/mel_a_a.lua")
--	dofile(path .. "/mel_a_w.lua")

--	humanoids, animals & monsters
--	dofile(path .. "/mel_c_a.lua")
--	dofile(path .. "/mel_c_m.lua")	--

--  Kingdoms
dofile(path .. "/mel_TA.lua")	-- Ruby Kingdom --
dofile(path .. "/mel_TAa.lua")
dofile(path .. "/mel_TAb.lua")
dofile(path .. "/mel_TB.lua")	--	Bimbam Kingdom	--
--	dofile(path .. "/mel_TBa.lua")
dofile(path .. "/mel_TC.lua")	--	Candy Kingdom	--
dofile(path .. "/mel_TCa.lua")
dofile(path .. "/mel_TCb.lua")
--	dofile(path .. "/mel_TD.lua")	--



print ("[MOD] Mobs Redo 'Melmel' loaded")