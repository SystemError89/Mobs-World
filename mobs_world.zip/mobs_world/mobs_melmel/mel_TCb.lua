-- Candy Kingdom

--	Citizens


--	Candy Creature A
mobs:register_mob("mobs_melmel:mmTCcca", {
	type = "tc",
	hp_min = 16,
	hp_max = 16,
	collisionbox = {-0.98, -0.01, -1.02, 0.98, 2, 0.98},
	visual_size = {x=10, y=10},
	textures = {
				{ "TC_cca1.png" },
				{ "TC_cca2.png" },
--				{ "TC_cca3.png" },
--				{ "TC_cca4.png" },
				},
	visual = "mesh",
	mesh = "mobs_mc_magmacube.b3d",
	blood_texture = "mobs_mc_magmacube_blood.png",
	makes_footstep_sound = true,
--	sounds = {
--		jump = "green_slime_jump",
--		death = "green_slime_death",
--		damage = "green_slime_damage",
--		attack = "green_slime_attack",
--		distance = 16,
--	},
	walk_velocity = 4,
	run_velocity = 4,
	damage = 6,
	reach = 3,
	armor = 40,
	drops = {
		{name = "farming:bread",
		chance = 4,	min = 1,	max = 1,},
	},
	-- TODO: Fix animations
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 6,
	walk_chance = 2,
	jump_chance = 100,
	fear_height = 10000,
})

--	Candy Creature B (small)
mobs:register_mob("mobs_melmel:mmTCccb", {
	type = "tc",
	hp_min = 16,
	hp_max = 16,
	collisionbox = {-0.51, -0.01, -0.51, 0.51, 1.00, 0.51},
	visual_size = {x=6.25, y=6.25},
	textures = {
				{ "TC_ccb1.png" },
				{ "TC_ccb2.png" },
				{ "TC_ccb3.png" },
				{ "TC_ccb4.png" },
				},
	visual = "mesh",
	mesh = "mobs_mc_magmacube.b3d",
	blood_texture = "mobs_mc_magmacube_blood.png",
	makes_footstep_sound = true,
--	sounds = {
--		jump = "green_slime_jump",
--		death = "green_slime_death",
--		damage = "green_slime_damage",
--		attack = "green_slime_attack",
--		distance = 16,
--	},
	walk_velocity = 4,
	run_velocity = 4,
	damage = 6,
	reach = 3,
	armor = 40,
	drops = {
		{name = "farming:bread",
		chance = 4,	min = 1,	max = 1,},
	},
	-- TODO: Fix animations
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 6,
	walk_chance = 2,
	jump_chance = 100,
	fear_height = 10000,
})

--	Candy Creature C (tiny)
mobs:register_mob("mobs_melmel:mmTCccc", {
	type = "tc",
	hp_min = 16,
	hp_max = 16,
	collisionbox = {-0.2505, -0.01, -0.2505, 0.2505, 0.50, 0.2505},
	visual_size = {x=3.125, y=3.125},
	textures = {
				{ "TC_ccc1.png" },
				{ "TC_ccc2.png" },
--				{ "TC_ccc3.png" },
--				{ "TC_ccc4.png" },
				},
	visual = "mesh",
	mesh = "mobs_mc_magmacube.b3d",
	blood_texture = "mobs_mc_magmacube_blood.png",
	makes_footstep_sound = true,
--	sounds = {
--		jump = "green_slime_jump",
--		death = "green_slime_death",
--		damage = "green_slime_damage",
--		attack = "green_slime_attack",
--		distance = 16,
--	},
	walk_velocity = 4,
	run_velocity = 4,
	damage = 6,
	reach = 3,
	armor = 40,
	drops = {
		{name = "farming:bread",
		chance = 4,	min = 1,	max = 1,},
	},
	-- TODO: Fix animations
	animation = {
		speed_normal = 24,
		speed_run = 48,
		stand_start = 0,
		stand_end = 23,
		walk_start = 24,
		walk_end = 47,
		run_start = 48,
		run_end = 62,
		hurt_start = 64,
		hurt_end = 86,
		death_start = 88,
		death_end = 118,
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	attack_type = "dogfight",
	passive = false,
	jump = true,
	jump_height = 6,
	walk_chance = 2,
	jump_chance = 100,
	fear_height = 10000,
})

-- Candy Creature D (chicken mesh)
mobs:register_mob("mobs_melmel:mmTCccd", {
	type = "animal", "tc",

	hp_min = 4,
	hp_max = 4,
	collisionbox = {-0.2, -0.01, -0.2, 0.2, 0.69, 0.2},
	runaway = true,
	floats = 1,
	visual = "mesh",
	mesh = "mobs_mc_chicken.b3d",
	textures = {
		{"TC_ccd1.png"},
--		{"TC_ccd2.png"},
--		{"TC_ccd3.png"},
--		{"TC_ccd4.png"},
	},
	visual_size = {x=2.2, y=2.2},

	makes_footstep_sound = true,
	walk_velocity = 1,
	drops = {
		{name = "default:apple",
		chance = 1,
		min = 1,
		max = 1,},
--		{name = mobs_mc.items.feather,
--		chance = 1,
--		min = 0,
--		max = 2,},
	},
	water_damage = 1,
	lava_damage = 4,
	light_damage = 0,
	fall_damage = 0,
	fall_speed = -2.25,
--	sounds = {
--		random = "mobs_chicken",
--		death = "Chickenhurt1", -- TODO: replace
--		damage = "Chickenhurt1", -- TODO: replace
--		distance = 16,
--	},
	animation = {
		stand_speed = 25, walk_speed = 25, run_speed = 50,
		stand_start = 0,		stand_end = 0,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
	},

--	follow = mobs_mc.follow.chicken,
	view_range = 16,
	fear_height = 4,

	on_rightclick = function(self, clicker)
		if mobs:feed_tame(self, clicker, 1, true, true) then return end
		if mobs:protect(self, clicker) then return end
		if mobs:capture_mob(self, clicker, 0, 60, 5, false, nil) then return end
	end,

	do_custom = function(self, dtime)

		self.egg_timer = (self.egg_timer or 0) + dtime
		if self.egg_timer < 10 then
			return
		end
		self.egg_timer = 0

		if self.child
		or math.random(1, 100) > 1 then
			return
		end

		local pos = self.object:get_pos()

		minetest.add_item(pos, "mobs:egg")

		minetest.sound_play("default_place_node_hard", {
			pos = pos,
			gain = 1.0,
			max_hear_distance = 5,
		})
	end,	
	
})

-- Cande Creature E
mobs:register_mob("mobs_melmel:mmTCcce", {
	type = "tc", "npc",
	passive = true,
	hp_min = 4,
	hp_max = 4,
	pathfinding = 1,
	view_range = 10,
	fall_damage = 0,
	water_damage = 4,
	lava_damage = 20,
	attacks_monsters = true,
	collisionbox = {-0.35, -0.01, -0.35, 0.35, 1.89, 0.35},
	visual = "mesh",
	mesh = "mobs_mc_snowman.b3d",
	textures = {
		{"TC_cce1.png^TC_ccex.png"},
		{"TC_cce2.png^TC_ccex.png"},
		{"TC_cce3.png^TC_ccex.png"},
		{"TC_cce4.png^TC_ccex.png"},
		{"TC_cce5.png^TC_ccex.png"},
		{"TC_cce6.png^TC_ccex.png"},
		{"TC_cce7.png^TC_ccex.png"},
		{"TC_cce8.png^TC_ccex.png"},
	},
	gotten_texture = { "TC_cce1.png" },
	drops = {{ name = "farming:bread", chance = 1, min = 0, max = 15 }},
	visual_size = {x=3, y=3},
	walk_velocity = 0.6,
	run_velocity = 2,
	jump = true,
	makes_footstep_sound = true,
	attack_type = "shoot",
	arrow = "mobs:arrow",
	shoot_interval = 1,
	shoot_offset = 1,
	animation = {
		speed_normal = 25,
		speed_run = 50,
		stand_start = 20,
		stand_end = 40,
		walk_start = 0,
		walk_end = 20,
		run_start = 0,
		run_end = 20,
		die_start = 40,
		die_end = 50,
		die_loop = false,
	},
	blood_amount = 0,
--	do_custom = function(self, dtime)
--		if not mobs_griefing then
--			return
--		end
--		-- Leave a trail of top snow behind.
--		-- This is done in do_custom instead of just using replace_what because with replace_what,
--		-- the top snop may end up floating in the air.
--		if not self._snowtimer then
--			self._snowtimer = 0
--			return
--		end
--		self._snowtimer = self._snowtimer + dtime
--		if self.health > 0 and self._snowtimer > snow_trail_frequency then
--			self._snowtimer = 0
--			local pos = self.object:getpos()
--			local below = {x=pos.x, y=pos.y-1, z=pos.z}
--			local def = minetest.registered_nodes[minetest.get_node(pos).name]
--			-- Node at snow golem's position must be replacable
--			if def and def.buildable_to then
--				-- Node below must be walkable
--				-- and a full cube (this prevents oddities like top snow on top snow, lower slabs, etc.)
--				local belowdef = minetest.registered_nodes[minetest.get_node(below).name]
--				if belowdef and belowdef.walkable and (belowdef.node_box == nil or belowdef.node_box.type == "regular") then
--					-- Place top snow
--					minetest.set_node(pos, {name = mobs_mc.items.top_snow})
--				end
--			end
--		end
--	end,
	-- Remove pumpkin if using shears
--	on_rightclick = function(self, clicker)
--		local item = clicker:get_wielded_item()
--		if self.gotten ~= true and item:get_name() == mobs_mc.items.shears then
--			-- Remove pumpkin
--			self.gotten = true
--			self.object:set_properties({
--				textures = {"TC_cce7.png"},
--			})

--			local pos = self.object:getpos()
--			minetest.sound_play("shears", {pos = pos})

			-- Wear out
--			if not minetest.settings:get_bool("creative_mode") then
--				item:add_wear(mobs_mc.misc.shears_wear)
--				clicker:get_inventory():set_stack("main", clicker:get_wield_index(), item)
--			end
--		end
--	end,
})

--	Flying Cookie
mobs:register_mob("mobs_melmel:mmTCfc", {
	type = "tc", "npc",
	hp_min = 30,
	hp_max = 30,
    	passive = false,
	attack_type = "dogfight",
	pathfinding = 1,
	view_range = 16,
	walk_velocity = 2,
	run_velocity = 4,
	damage = 6,
	reach = 3,
	collisionbox = {-0.425, 0.25, -0.425, 0.425, 1.1, 0.425},
	visual = "mesh",
	mesh = "mobs_mc_guardian.b3d",
	textures = {
		{"TC_fc1.png"},
		{"TC_fc2.png"},
		{"TC_fc3.png"},
	},
	visual_size = {x=3, y=3},
	sounds = {
		damage = "mobs_mc_squid_hurt",
		distance = 16,
	},
	animation = {
		stand_speed = 25, walk_speed = 25, run_speed = 50,
		stand_start = 0,		stand_end = 20,
		walk_start = 0,		walk_end = 20,
		run_start = 0,		run_end = 20,
	},
	drops = {
		{name = "farming:bread",
		chance = 1,	min = 0,	max = 2,},
	},
	fly = true,
--	fly_in = { mobs_mc.items.water_source, mobs_mc.items.river_water_source },
	stepheight = 0.1,
	jump = false,
	view_range = 16,
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	blood_amount = 0,
})

-- Flying Pig
mobs:register_mob("mobs_melmel:mmTCfp", {
	type = "animal", "tc",
	passive = true,
	reach = 4,
	damage = 2,
	attack_type = "explode",
	explosion_radius = 3,
	hp_min = 12,
	hp_max = 22,
	armor = 130,
	collisionbox = {-0.4, 0, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "flying_pig.b3d",
	textures = {
		{"TC_fp1.png"},
		{"TC_fp1m.png"},
	},
   jump = true,
   fly = true,
   fall_speed = 0,
   stepheight = 1.5,
	blood_texture = "mobs_blood.png",
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	runaway = false,
	walk_velocity = 2,
	run_velocity = 3,
	run_chance = 20,
	jump = true,
	drops = {
		{name = "mobs:meat_raw", chance = 2, min = 1, max = 1},
	},
	sounds = {
      random = "mobs_pig",
	  explode = "tnt_explode",
	},
	do_custom = function(self)
		if self.state == "attack" then
			self.fly = false
			self.fall_speed = -4
		end
	end,
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	follow = {"default:apple"},
	view_range = 14,
	animation = {
		speed_normal = 10,
		speed_run = 15,
		walk_start = 1,
		walk_end = 20,
		stand_start = 1,
		stand_end = 20,
		run_start = 22,
		run_end = 28,

	},
	on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 8, true, true) then
			return
		end

		mobs:capture_mob(self, clicker, 0, 5, 50, false, nil)
	end,
})

mobs:register_mob("mobs_melmel:mmTCnc", {
	type = "animal", "tc",
	passive = true,
	reach = 4,
	damage = 2,
	hp_min = 12,
	hp_max = 22,
	armor = 130,
	collisionbox = {-0.2, 0, -0.2, 0.2, 0.6, 0.2},
	visual = "mesh",
	mesh = "nyancat.b3d",
	textures = {
		{"TC_nc.png"},
	},
   jump = true,
   fly = true,
   fall_speed = 0,
   stepheight = 1.5,
	blood_texture = "mobs_blood.png",
	visual_size = {x=1, y=1},
	makes_footstep_sound = true,
	runaway = false,
	walk_velocity = 2,
	run_velocity = 3,
	run_chance = 20,
	jump = true,
	drops = {
		{name = "default:nyan_cat", chance = 2, min = 1, max = 1},
	},
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	follow = {"default:mese"},
	view_range = 14,
	animation = {
		speed_normal = 4,
		speed_run = 5,
		walk_start = 1,
		walk_end = 7,
		stand_start = 1,
		stand_end = 7,
		run_start = 1,
		run_end = 7,

	},
   do_custom = function(self)
   local apos = self.object:get_pos()
		local vec = self.object:get_velocity()
		local part = minetest.add_particlespawner(
			5, --amount
			0.3, --time
			{x=apos.x-0.1, y=apos.y+0.3, z=apos.z-0.1}, --minpos
			{x=apos.x+0.1, y=apos.y+0.4, z=apos.z+0.1}, --maxpos
			{x=-0, y=-0, z=-0}, --minvel
			{x=0, y=0, z=0}, --maxvel
			{x=0,y=0,z=0}, --minacc
			{x=-vec.x,y=0,z=-vec.z}, --maxacc
			0.5, --minexptime
			1.5, --maxexptime
			3, --minsize
			5, --maxsize
			false, --collisiondetection
			"dmobs_rainbow.png" --texture
		)
   end,
	on_rightclick = function(self, clicker)

		if mobs:feed_tame(self, clicker, 8, true, true) then
			return
		end

		mobs:capture_mob(self, clicker, 0, 5, 50, false, nil)
	end,
})


-- ninja spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)


mobs:register_egg("mobs_melmel:mmTCcca", "Candy Creature (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCccb", "Candy Creature s (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCccc", "Candy Creature t (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCccd", "Candy Creature d (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCcce", "Candy Creature e (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCfc", "Flying Cookie (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCfp", "Flying Pig (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCnc", "Nyan Cat (mmTC)", "default_leaves.png", 1)