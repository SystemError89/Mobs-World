-- Candy Kingdom

--	TC


-- Candy Princess
mobs:register_mob("mobs_melmel:mmTCq", {
	-- animal, monster, npc
	name = "mmTCq",
	type = "tc", "npc",
	knock_back = .9,
	damage = 4,
	attack_type = "dogfight",
	reach = 2,
	attack_monsters = true,
	attack_armycs = false,
	attacks_tcs = false,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = true,
	group_attack = false,
	peaceful = true,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 20, hp_max = 33, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
--	rotate = 180,
	drawtype = "front",
	textures = {
		{"TC_queen.png",	"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	stepheight = 1.2,
	walk_velocity = 0.75,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 18,
	-- model animation
	animation = {
		speed_normal = 15,		speed_run = 30,
		stand_start = 0,		stand_end = 80,
		walk_start = 168,		walk_end = 187,
		run_start = 0,			run_end = 40,
		punch_start = 200,		punch_end = 219,
		shoot_start = 168,		shoot_end = 188,
	},
})

--	Earl Chocolate
mobs:register_mob("mobs_melmel:mmTCec", {
	type = "tc", "npc",
	hp_min = 30,
	hp_max = 30,
    	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	view_range = 16,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 6,
	reach = 3,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"TC_earl.png",		"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
	},
	visual_size = {x=1, y=1},
--	sounds = {
--		damage = "mobs_mc_squid_hurt",
--		distance = 16,
--	},
	animation = {
		stand_speed = 25, 	walk_speed = 20, 	run_speed = 30,
		stand_start = 0,	stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
	},
	drops = {
		{name = "farming:bread",
		chance = 1,	min = 0,	max = 2,},
	},
	fly = false,
--	fly_in = { mobs_mc.items.water_source, mobs_mc.items.river_water_source },
--	stepheight = 0.1,
	jump = true,
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	blood_amount = 0,
})

--	Peppermint Butler
mobs:register_mob("mobs_melmel:mmTCpb", {
	type = "tc", "npc",
	hp_min = 30,
	hp_max = 30,
    	passive = false,
	attack_type = "dogfight",
	pathfinding = true,
	view_range = 16,
	walk_velocity = 1,
	run_velocity = 3,
	damage = 6,
	reach = 3,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"TC_pb1.png",		"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
		{"TC_pb2.png",		"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
		{"TC_pb3.png",		"3d_armor_trans.png",	minetest.registered_items["mobs_stoneage:weapon_cudgel"].inventory_image,},
	},
	visual_size = {x=1, y=0.5},
--	sounds = {
--		damage = "mobs_mc_squid_hurt",
--		distance = 16,
--	},
	animation = {
		stand_speed = 25, 	walk_speed = 20, 	run_speed = 30,
		stand_start = 0,	stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
	},
	drops = {
		{name = "farming:bread",
		chance = 1,	min = 0,	max = 2,},
	},
	fly = false,
--	fly_in = { mobs_mc.items.water_source, mobs_mc.items.river_water_source },
--	stepheight = 0.1,
	jump = true,
	water_damage = 0,
	lava_damage = 4,
	light_damage = 0,
	blood_amount = 0,
})


-- ninja spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)


mobs:register_egg("mobs_melmel:mmTCq", "Candy Queen (gTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCec", "Earl Chocolate  (mmTC)", "default_leaves.png", 1)
mobs:register_egg("mobs_melmel:mmTCpb", "Peppermint Butler (mmTC)", "default_leaves.png", 1)
--	mobs:register_egg("mobs_melmel:mmTCh", "Cave Hunter (mmTC)", "default_leaves.png", 1)