Modern World Mobs


contains:


*Team A	inspired by USA
*Team B	inspired by China
*Team C	isnpired by Arabia
*Team D	inspired by Russia
*Team E	inspired by Europe
*Team F	inspired by South America
*Team T	inspired by Terrorists


	Team A:	- citizens
			- nice citizen
			- normal citizen
			- poor citizen
			- criminal

			- police officer
			- swat officer
			- Agent

			- Gang B Boss
			- Gang B Member

			- Gang B Boss
			- Gang B Member


		- soldiers
			- Officer
			- Special Unit
			- Soldier
			- Sniper
			- Rocket Guy
			- Drone
			- Uncle Sam

	Team D:	- citizens
			- nice citizen
			- normal citizen
			- poor citizen
			- criminal

			- police officer
			- swat officer
			- Agent

		- soldiers
			- Officer
			- Special Unit
			- Soldier
			- Sniper
			- Rocket Guy
			- Drone
			- Tank
			- Ivan
