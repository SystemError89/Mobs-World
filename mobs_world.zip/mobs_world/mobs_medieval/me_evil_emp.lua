-- Medieval Folk ( Evil Kingdom )


-- King

mobs:register_mob("mobs_medieval:EvilKing", {
	-- animal, monster, npc
	name = "EvilKing",
	nametag = "Evil King",
	type = "evil",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 7, -- shoot for 10 seconds
	dogshoot_count2_max = 8, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	peaceful = false,
	passive = true,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240,
	armor = 75,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_emp_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
   		{"EVIL_emp_king2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
   		{"EVIL_emp_queen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 4,
	jump = true,
	jump_height = 7,
	fall_speed = -6,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	view_range = 18,
	floats = .3,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

-- Master

mobs:register_mob("mobs_medieval:EVILmas", {
	-- animal, monster, npc
	name = "EVILofi",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 4, -- shoot for 10 seconds
	dogshoot_count2_max = 11, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = 1.8,
	arrow = "mobs_medieval:fireball",
	shoot_offset = 1,
	atacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 36, hp_max = 47,
	armor = 80,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_emp_ofi1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_ofi2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_ofi3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_ofi4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_ofi5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_ofi5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.1, y=1.2},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 2,
	view_range = 20,
	floats = 1.3,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Knight

mobs:register_mob("mobs_medieval:EVILkni", {
	-- animal, monster, npc
	name = "EVILknight",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 55,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_emp_knight1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"EVIL_emp_knight5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_knight11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Troop

mobs:register_mob("mobs_medieval:EVILtro", {
	-- animal, monster, npc
	name = "EVILtroop",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 36, hp_max = 46, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_troop1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_troop6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_troop9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 4,
	view_range = 12,
	floats = .2,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Warrior

mobs:register_mob("mobs_medieval:EVILwar", {
	-- animal, monster, npc
	name = "EVILwar",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_emp_war1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_emp_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_emp_war9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_war11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 5,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Archer

mobs:register_mob("mobs_medieval:EVILarc", {
	-- animal, monster, npc
	name = "EVILarc",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 2,
	reach = 2,
	attack_type = "shoot",
	arrow = "mobs_medieval:arrow1",
	balistic = true,
	shoot_interval = .7,
	shoot_offset = 2,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	-- health & armor
	hp_min = 27, hp_max = 34,
	armor_groups= { daemonic=50, },
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_emp_arc1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"EVIL_emp_arc2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_arc3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_emp_arc4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Villager

mobs:register_mob("mobs_medieval:EVILvil", {
	-- animal, monster, npc
	name = "EVILvil",
	type = "evil",
	owner = "EvilKing",
	-- aggressive, shoots shuriken
	damage = 3,
	reach = 2,
	attack_type = "dogfight",
	shoot_interval = .5,
	shoot_offset = 2,
	attacks_npcs = true,
	attack_armyas = true,
	attack_tas = true,
	attack_armybs = true,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	-- health & armor
	hp_min = 20, hp_max = 30, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_vil1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"EVIL_vil2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"EVIL_vil6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"EVIL_vil10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil12.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil13.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vil14.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"EVIL_vilf2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"EVIL_vilf6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_vilf9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	floats = 1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})



-- mobs spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_medieval:EvilKing", "King (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmas", "Officer (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILkni", "Knight (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILtro", "Troop (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILwar", "Warrior (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILarc", "Archer (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILvil", "Villager (Evil)", "default_leaves.png", 1)