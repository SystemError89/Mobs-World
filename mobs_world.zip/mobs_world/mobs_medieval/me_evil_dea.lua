-- Medieval Folk ( Team Evil - Deamons )


-- Deamon King

mobs:register_mob("mobs_medieval:EvildeaKing", {
	-- animal, monster, npc
	name = "EvildeaKing",
	nametag = "Deamon King",
	type = "evil",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 7, -- shoot for 10 seconds
	dogshoot_count2_max = 8, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240,
	armor = 60,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_dea_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
--   		{"EVIL_dea_queen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 4,
	jump = true,
	jump_height = 7,
	fall_speed = -6,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	view_range = 18,
	floats = .3,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

-- Officer

mobs:register_mob("mobs_medieval:EVILdeaofi", {
	-- animal, monster, npc
	name = "EVILdeaofi",
	type = "evil",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 4, -- shoot for 10 seconds
	dogshoot_count2_max = 11, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = 1.8,
	arrow = "mobs_medieval:fireball",
	shoot_offset = 1,
	atacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 36, hp_max = 47,
	armor = 50,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_dea_ofi1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_ofi2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_ofi3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_ofi4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_ofi5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_ofi6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.2, y=1.4},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 2,
	view_range = 20,
	floats = 1.6,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Dungeon Master by PilzAdam

mobs:register_mob("mobs_medieval:EVILdm", {
	type = "evil", "monster",
	passive = false,
	damage = 9,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 2, -- shoot for 10 seconds
	dogshoot_count2_max = 13, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = 2.5,
	arrow = "mobs_medieval:fireball",
	shoot_offset = 1,
	attack_armyas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armycs = true,
	attack_armyds = true,
	attack_evils = false,
	peaceful = false,
	hp_min = 42,
	hp_max = 75,
	armor = 60,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "mesh",
	mesh = "mobs_dungeon_master.b3d",
	textures = {
		{"EVIL_dea_dm1.png"},
		{"EVIL_dea_dm2.png"},
		{"EVIL_dea_dm3.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_dungeonmaster",
		shoot_attack = "mobs_fireball",
	},
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	view_range = 15,
	drops = {
		{name = "default:mese_crystal_fragment", chance = 1, min = 0, max = 2},
		{name = "mobs:leather", chance = 2, min = 0, max = 2},
		{name = "default:mese_crystal", chance = 3, min = 0, max = 2},
		{name = "default:diamond", chance = 4, min = 0, max = 1},
		{name = "default:diamondblock", chance = 30, min = 0, max = 1},
	},
	water_damage = 1,
	lava_damage = 1,
	light_damage = 0,
	fear_height = 3,
	animation = {
		stand_start = 0,
		stand_end = 19,
		walk_start = 20,
		walk_end = 35,
		punch_start = 36,
		punch_end = 48,
		shoot_start = 36,
		shoot_end = 48,
		speed_normal = 15,
		speed_run = 15,
	},
})

-- Knight

mobs:register_mob("mobs_medieval:EVILdeaknight", {
	-- animal, monster, npc
	name = "EVILdeaknight",
	type = "evil",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 55,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_dea_knight1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_knight2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_knight3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_knight4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"EVIL_dea_knight5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_knight6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_knight8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_knight9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.3, y=1.3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Warrior

mobs:register_mob("mobs_medieval:EVILdeawar", {
	-- animal, monster, npc
	name = "EVILdeawar",
	type = "evil",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 80,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_dea_war1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_war2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_war3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_war4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--	   	{"EVIL_dea_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Archer

mobs:register_mob("mobs_medieval:EVILdeaarc", {
	-- animal, monster, npc
	name = "EVILdeaarc",
	type = "evil",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 2,
	reach = 2,
	attack_type = "shoot",
	arrow = "mobs_medieval:arrow1",
	balistic = true,
	shoot_interval = .7,
	shoot_offset = 2,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 27, hp_max = 34,
	armor_groups= { daemonic=50, },
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
--		{"EVIL_dea_arc1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   	{"EVIL_dea_arc2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_arc3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_dea_arc4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Villager

mobs:register_mob("mobs_medieval:EVILdeavil", {
	-- animal, monster, npc
	name = "EVILdeavil",
	type = "evil", "monster",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 1,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_dea_vil1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_vil2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_vil3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_vil4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_vil5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_dea_vil6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_dea_vil7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_dea_vil8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Create the textures table for the enderman, depending on which kind of block
-- the enderman holds (if any).
local create_enderman_textures = function(block_type, itemstring)
	local base = "mobs_mc_enderman.png^mobs_mc_enderman_eyes.png"

	--[[ Order of the textures in the texture table:
		Flower, 90 degrees
		Flower, 45 degrees
		Held block, backside
		Held block, bottom
		Held block, front
		Held block, left
		Held block, right
		Held block, top
		Enderman texture (base)
	]]
	-- Regular cube
	if block_type == "cube" then
		local tiles = minetest.registered_nodes[itemstring].tiles
		local textures = {}
		local last
		if mobs_mc.enderman_block_texture_overrides[itemstring] then
			-- Texture override available? Use these instead!
			textures = mobs_mc.enderman_block_texture_overrides[itemstring]
		else
			-- Extract the texture names
			for i = 1, 6 do
				if type(tiles[i]) == "string" then
					last = tiles[i]
				elseif type(tiles[i]) == "table" then
					if tiles[i].name then
						last = tiles[i].name
					end
				end
				table.insert(textures, last)
			end
		end
		return {
			"blank.png",
			"blank.png",
			textures[5],
			textures[2],
			textures[6],
			textures[3],
			textures[4],
			textures[1],
			base, -- Enderman texture
		}
	-- Node of plantlike drawtype, 45° (recommended)
	elseif block_type == "plantlike45" then
		local textures = minetest.registered_nodes[itemstring].tiles
		return {
			"blank.png",
			textures[1],
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base,
		}
	-- Node of plantlike drawtype, 90°
	elseif block_type == "plantlike90" then
		local textures = minetest.registered_nodes[itemstring].tiles
		return {
			textures[1],
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base,
		}
	elseif block_type == "unknown" then
		return {
			"blank.png",
			"blank.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			base, -- Enderman texture
		}
	-- No block held (for initial texture)
	elseif block_type == "nothing" or block_type == nil then
		return {
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base, -- Enderman texture
		}
	end
end

-- Deamon (long)

mobs:register_mob("mobs_medieval:EVILdeaB", {
	-- animal, monster, npc
	name = "EVILdeaB",
	type = "evil", "monster",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	stepheight = 1.2,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.3, -0.01, -0.3, 0.3, 2.89, 0.3},
	visual = "mesh",
	mesh = "mobs_enderman.b3d",
	textures = create_enderman_textures(),
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Deamon (Golem)

mobs:register_mob("mobs_medieval:EVILdeaC", {
	-- animal, monster, npc
	name = "EVILdeaC",
	type = "evil", "monster",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 55,
	-- textures and model
	collisionbox = {-0.7, -0.01, -0.7, 0.7, 2.69, 0.7},
	visual = "mesh",
	mesh = "mobs_golem.b3d",
	textures = {
		{"EVIL_dea_gol1.png"},
		{"EVIL_dea_gol2.png"},
		{"EVIL_dea_gol3.png"},
		{"EVIL_dea_gol4.png"},
		{"EVIL_dea_gol5.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_dea_gol6.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_gol7.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_gol8.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_gol9.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 2,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 20,
		stand_start = 0,		stand_end = 79,
		walk_start = 0,		walk_end = 40,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Deamon (Ghast)

mobs:register_mob("mobs_medieval:EVILdeaD", {
	-- animal, monster, npc
	name = "EVILdeaD",
	type = "evil", "monster",
	owner = "EvildeaKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 16, hp_max = 32, armor = 85,
	-- textures and model
	collisionbox = {-0.7, -0.01, -0.7, 0.7, 2.69, 0.7},
	visual = "mesh",
	mesh = "mobs_mc_ghast.b3d",
	textures = {
		{"EVIL_dea_gha1.png"},
		{"EVIL_dea_gha2.png"},
		{"EVIL_dea_gha3.png"},
		{"EVIL_dea_gha4.png"},
		{"EVIL_dea_gha5.png"},
 		{"EVIL_dea_gha6.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_dea_gha7.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 2,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 20,
		stand_start = 0,		stand_end = 79,
		walk_start = 0,		walk_end = 40,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Hellhound (original: Wolf by KrupnoPavel)

mobs:register_mob("mobs_medieval:EVILdeaHound", {
	type = "evil", "monster", "animal",
	hp_max = 12,
	passive = false,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "mobs_hound.x",
	textures = {
		{"EVIL_dea_hound1.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		war_cry = "mobs_wolf_attack",
	},
	view_range = 10,
	walk_velocity = 2,
	run_velocity = 5,
	stepheight = 1.1,
	damage = 5,
	armor = 200,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	animation = {
		speed_normal = 20,
		speed_run = 50,
		stand_start = 10,
		stand_end = 20,
		walk_start = 75,
		walk_end = 100,
		run_start = 100,
		run_end = 130,
		punch_start = 135,
		punch_end = 155,
	},
	jump = true,
	step = 0.5,
	blood_texture = "mobs_blood.png",
})

-- Hellhound 2 (original: Wolf by KrupnoPavel)

mobs:register_mob("mobs_medieval:EVILdeaHoundB", {
	type = "evil", "monster", "animal",
	hp_max = 12,
	passive = false,
	collisionbox = {-0.4, -0.01, -0.4, 0.4, 1, 0.4},
	visual = "mesh",
	mesh = "mobs_mc_wolf.b3d",
	textures = {
		{"EVIL_dea_hound2.png"},
		{"EVIL_dea_hound3.png"},
		{"EVIL_dea_hound4.png"},
		{"EVIL_dea_hound5.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		war_cry = "mobs_wolf_attack",
	},
	view_range = 10,
	walk_velocity = 2,
	run_velocity = 5,
	stepheight = 1.1,
	damage = 5,
	armor = 200,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	drops = {
		{name = "mobs:meat_raw",
		chance = 1,
		min = 2,
		max = 3,},
	},
	drawtype = "front",
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	animation = {
		speed_normal = 20,
		speed_run = 50,
		stand_start = 10,
		stand_end = 20,
		walk_start = 75,
		walk_end = 100,
		run_start = 100,
		run_end = 130,
		punch_start = 135,
		punch_end = 155,
	},
	jump = true,
	step = 0.5,
	blood_texture = "mobs_blood.png",
})



-- mobs spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_medieval:EvildeaKing", "Deamon King", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaofi", "Big Deamon", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdm", "Dungeon Master", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaknight", "Deamon Knight", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeawar", "Deamon Warrior", "default_leaves.png", 1)
--	mobs:register_egg("mobs_medieval:EVILdeaarc", "Deamon Archer", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeavil", "Deamon Villager", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaB", "Deamon Tall", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaC", "Deamon Golem", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaD", "Deamon Ghast", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaHound", "Hellhound", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILdeaHoundB", "HellhoundB", "default_leaves.png", 1)