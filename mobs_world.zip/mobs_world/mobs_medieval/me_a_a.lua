-- -------------------------------------------------------------------------------------------------------------
-- ----  ----  ----  ----  ----  ----  ----  ----  -- Arrows --  ----  ----  ----  ----  ----  ----  ----  ----
-- -------------------------------------------------------------------------------------------------------------


-- fireball (weapon)
mobs:register_arrow("mobs_medieval:fireball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"mobs_fireball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "mobs_fireball.png",
	tail_size = 10,
	glow = 5,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})

-- fireball3 (weapon)
mobs:register_arrow("mobs_medieval:fireball3", {
	visual = "sprite",
	visual_size = {x = 0.7, y = 0.7},
	textures = {"mobs_fireball3.png"},
	velocity = 7,
	tail = 1,
	tail_texture = "mobs_fireball3.png",
	tail_size = 10,
	glow = 6,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 14},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 20},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})