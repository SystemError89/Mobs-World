-- Medieval Folk ( Team B - Group A )


-- King

mobs:register_mob("mobs_medieval:TBAkin", {
	-- animal, monster, npc
	name = "TBAking",
	type = "armyba",
	-- aggressive, shoots shuriken
	damage = 8,
	attack_type = "dogshoot",
	reach = 2,
	arrow = "mobs_medieval:arrow1",
	attacks_npcs = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	group_attack = true,
	peaceful = true,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240, armor = 95,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
   		{"TBA_king2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Officer

mobs:register_mob("mobs_medieval:TBAmas", {
	-- animal, monster, npc
	name = "TBAmaster",
	type = "armyba",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogfight",
	shoot_interval = .6,
	shoot_offset = 2,
	attacks_npcs = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 36, hp_max = 47, armor_groups = {fleshy=90,	daemon=35},
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_ofi1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi2.png",		"3d_armor_leather1.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ofi7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 15,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Knight

mobs:register_mob("mobs_medieval:TBAkni", {
	-- animal, monster, npc
	name = "TBAknight",
	type = "armyba", "tb",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attacks_npcs = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 65,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_knight1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_knight11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 11,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Troop

mobs:register_mob("mobs_medieval:TBAtro", {
	-- animal, monster, npc
	name = "TBAtro",
	type = "armyba",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogfight",
	shoot_interval = .6,
	shoot_offset = 2,
	attacks_npcs = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 36, hp_max = 47, armor_groups = {fleshy=90,	daemon=35},
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_troop1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop2.png",	"3d_armor_leather1.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_troop11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 15,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Ninja

mobs:register_mob("mobs_medieval:TBAnin", {
	-- animal, monster, npc
	name = "TBAtro",
	type = "armyba",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "shoot",
	shoot_interval = .5,
	arrow = "mobs_medieval:shuriken",
	shoot_offset = 2,
	attacks_npcs = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = false,
	attacks_tes = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	attacks_monsters = true,
	attacks_animals = true,
	-- health & armor
	hp_min = 20, hp_max = 30, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_ninja1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_ninja2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ninja3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_ninja4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "mobs:shuriken",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 15,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
	},
})

-- Warrior

mobs:register_mob("mobs_medieval:TBAwar", {
	-- animal, monster, npc
	name = "TBAwar",
	type = "armyba", "tb",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attacks_monsters = true,
	attack_animals = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_tbs = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	group_attack = true,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_war1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_war2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_war10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war12.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_war13.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_war14.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 14,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Archer

mobs:register_mob("mobs_medieval:TBAarc", {
	-- animal, monster, npc
	name = "TBAarc",
	type = "armyba", "tb",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 2,
	reach = 2,
	attack_type = "shoot",
	arrow = "mobs_medieval:arrow1",
	balistic = true,
	shoot_interval = .5,
	shoot_offset = 2,
	attacks_monsters = true,
	attack_animals = false,
	attack_armybas = false,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 27, hp_max = 34, armor = 90,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBA_arc1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"TBA_arc2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_arc3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBA_arc4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 17,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Villager

mobs:register_mob("mobs_medieval:TBAvil", {
	-- animal, monster, npc
	name = "TBAmvil",
	type = "tb", "armyba",
	owner = "TBAking",
	-- aggressive, shoots shuriken
	damage = 3,
	reach = 2,
	attack_type = "dogfight",
	shoot_interval = .5,
	shoot_offset = 2,
	attacks_monsters = true,
	attack_animals = false,
	attack_armybas = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 20, hp_max = 30, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"TBvil1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil12.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil13.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil14.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil15.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil16.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil17.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil18.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil19.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil20.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil21.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil22.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil23.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil24.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil25.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil26.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil27.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil30.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil31.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil32.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil33.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil34.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil35.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil34.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil37.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil38.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil39.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil40.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil41.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil42.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil43.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil44.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil45.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil46.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil47.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil48.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil50.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil51.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil52.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil60.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil61.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil62.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil63.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil64.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil65.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil66.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil67.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil68.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil69.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil70.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil71.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil72.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil73.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil74.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil75.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil76.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil77.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil78.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil79.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil80.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil81.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil82.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil83.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvil84.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil85.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil84.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvil87.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvilf2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvilf6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf12.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf13.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf14.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf20.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf21.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf29.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvilf30.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf31.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf32.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf33.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvilf34.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf35.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf34.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf37.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
   		{"TBvilf38.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"TBvilf39.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 15,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})



-- mobs spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_medieval:TBAkin", "King (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAmas", "Officer (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAtro", "Troop (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAnin", "Ninja (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAkni", "Knight (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAwar", "Warrior (TBA)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:TBAarc", "Archer (TBA)", "default_leaves.png", 1)
-- mobs:register_egg("mobs_medieval:TBAvil", "Villager (TBA)", "default_leaves.png", 1)