
local S = mobs.intllib


-- Monkey King

mobs:register_mob("mobs_animal:MonkeyK", {
stepheight = 0.6,
	type = "animal",
	passive = false,
	attack_type = "dogfight",
	group_attack = false,
	attack_npcs = false,
	attack_monsters = true,
	reach = 3,
	damage = 7,
	hp_min = 10,
	hp_max = 24,
	armor = 100,
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	textures = {
		{"MonkeyK.png",	"3d_armor_trans.png"},
	},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 5,
	walk_velocity = 0.5,
	run_velocity = 3.5,
	jump = true,
	jump_height = 6,
	fall_speed = -3,
	follow = {"ethereal:bamboo"},
	view_range = 12,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 15,		speed_run = 35,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
--	on_rightclick = function(self, clicker)

--		if mobs:feed_tame(self, clicker, 20, true, true) then return end
--		if mobs:protect(self, clicker) then return end
--		if mobs:capture_mob(self, clicker, 0, 5, 50, false, nil) then return end
--	end,
})

-- Monkey

mobs:register_mob("mobs_animal:MonkeyN", {
stepheight = 0.6,
	type = "animal",
	passive = false,
	attack_type = "dogfight",
	group_attack = false,
	attack_npcs = false,
	attack_monsters = true,
	reach = 2,
	damage = 3,
	hp_min = 10,
	hp_max = 24,
	armor = 200,
	collisionbox = {-0.4, -0.45, -0.4, 0.4, 0.45, 0.4},
	visual = "mesh",
	mesh = "amcaw_oldlady.b3d",
	textures = {
		{"MonkeyN.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 5,
	walk_velocity = 0.5,
	run_velocity = 1.5,
	jump = false,
	jump_height = 6,
	follow = {"ethereal:bamboo"},
	view_range = 8,
	pathfinding = true,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 15,
		stand_start = 130,
		stand_end = 270,
		stand1_start = 0,
		stand1_end = 0,
		stand2_start = 1,
		stand2_end = 1,
		stand3_start = 2,
		stand3_end = 2,
		walk_start = 10,
		walk_end = 70,
		run_start = 10,
		run_end = 70,
		punch_start = 80,
		punch_end = 120,
		-- 0 = rest, 1 = hiding (covers eyes), 2 = surprised
	},
})

-- Gorilla

mobs:register_mob("mobs_animal:MonkeyG", {
stepheight = 0.6,
	type = "animal",
	attack_type = "dogfight",
	attack_players = true,
	group_attack = false,
	passive = false,
	peaceful = false,
	reach = 2,
	damage = 6,
	hp_min = 10,
	hp_max = 24,
	armor = 95,
	collisionbox = {-0.7, -0.01, -0.7, 0.7, 2.69, 0.7},
	visual = "mesh",
	mesh = "mobs_golem.b3d",
	textures = {
		{"MonkeyG.png"},
	},
	visual_size = {x=2.7, y=2.7},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 5,
	walk_velocity = 0.5,
	run_velocity = 1,
	jump = false,
	jump_height = 2,
--	follow = {"ethereal:bamboo"},
	view_range = 8,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 10,		speed_run = 20,
		stand_start = 0,		stand_end = 79,
		walk_start = 0,		walk_end = 40,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})


--	---	----	-----	----------	----------	----------	----------	----------	-----	----	---	--

-- Tiger

mobs:register_mob("mobs_animal:Tiger", {
stepheight = 0.7,
	type = "animal",
	passive = false,
	attack_type = "dogfight",
	group_attack = false,
	attack_npcs = true,
	attack_monsters = true,
	attack_animals = true,
	peaceful = false,
	attack_chance = 95,
	reach = 2,
	damage = 5,
	hp_min = 10,
	hp_max = 24,
	armor = 200,
	collisionbox = {-0.4, -0.45, -0.4, 0.4, 0.45, 0.4},
	visual = "mesh",
	mesh = "mobs_mc_cat.b3d",
	textures = {
		{"tiger.png"},
	},
	visual_size = {x=3.4, y=3.2},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 95,
	walk_velocity = .5,
	run_velocity = 3.5,
	jump = true,
	jump_height = 2.1,
	view_range = 16,
	pathfinding = true,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 3.5,
	animation = {
		speed_normal = 15,		speed_run = 35,
		stand_start = 0,		stand_end = 0,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
	},
})

-- Cheetah

mobs:register_mob("mobs_animal:Cheetah", {
	type = "animal",
	passive = false,
	attack_type = "dogfight",
	group_attack = false,
	specific_attack = {"player", "mobs_animal:chicken", "mobs_animal:bunny", "mobs_animal:warthog", "mobs_animal:kitten"},
	peaceful = false,
	reach = 2,
	damage = 3,
	hp_min = 10,
	hp_max = 24,
	armor = 200,
	collisionbox = {-0.4, -0.45, -0.4, 0.4, 0.45, 0.4},
	visual = "mesh",
	mesh = "mobs_mc_cat.b3d",
	textures = {
		{"cheetah.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_velocity = .5,
	run_velocity = 3.5,
	jump = true,
	jump_height = 4.1,
	follow = {"mobs:meat_raw"},
	view_range = 20,
	pathfinding = true,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 7,
	animation = {
		speed_normal = 10,		speed_run = 70,
		stand_start = 0,		stand_end = 0,
		walk_start = 0,		walk_end = 40,
		run_start = 0,		run_end = 40,
	},
})


--	---	----	-----	----------	----------	----------	----------	----------	-----	----	---	--


-- Dragon A

mobs:register_mob("mobs_animal:DragonA", {
stepheight = 1.2,
	type = "animal",
	passive = false,
	attack_type = "dogfight",
	group_attack = false,
	reach = 2,
	damage = 9,
	hp_min = 100,
	hp_max = 124,
	armor = 80,
	collisionbox = {-2, 3, -2, 2, 5, 2},
	visual = "mesh",
	mesh = "mobs_mc_dragon.b3d",
	textures = {
		{"Dragon5.png"},
		{"Dragon6.png"},
		{"Dragon7.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 5,
	walk_velocity = 0.5,
	run_velocity = 1,
	jump = true,
	jump_height = 14,
	stepheight = 1.2,
	jump_chance = 100,
	fear_height = 120,	
	fly = true,
	fly_in = {"air"},
--	follow = {"ethereal:bamboo"},
	view_range = 8,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		fly_speed = 8, stand_speed = 8,
		stand_start = 0,		stand_end = 20,
		walk_start = 0,		walk_end = 20,
		run_start = 0,		run_end = 20,
	},
	blood_amount = 0,
})


-- Dragon B

mobs:register_mob("mobs_animal:DragonB", {
stepheight = 1.2,
	type = "monster",
	passive = false,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 7, -- shoot for 10 seconds
	dogshoot_count2_max = 8, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_animal:fireball3",
	shoot_offset = 2,
	attacks_players = true,
	attack_animals = true,
	attack_npcs = true,
	attacks_tas = true,
	attacks_tbs = true,
	attacks_tcs = true,
	attacks_tds = true,
	attacks_tes = true,
	
	group_attack = false,
	reach = 2,
	damage = 9,
	hp_min = 100,
	hp_max = 124,
	armor = 80,
	collisionbox = {-2, 3, -2, 2, 5, 2},
	visual = "mesh",
	mesh = "mobs_mc_dragon.b3d",
	textures = {
		{"Dragon1.png"},
		{"Dragon2.png"},
		{"Dragon4.png"},
	},
	visual_size = {x=3, y=3},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_panda",
		attack = "mobs_panda",
	},
	walk_chance = 5,
	walk_velocity = 0.5,
	run_velocity = 1,
	jump = true,
	jump_height = 14,
	stepheight = 1.2,
	jump_chance = 100,
	fear_height = 120,	
	fly = true,
	fly_in = {"air"},
--	follow = {"ethereal:bamboo"},
	view_range = 8,
	drops = {
		{name = "mobs:meat_raw", chance = 1, min = 1, max = 2},
	},
	water_damage = 1,
	lava_damage = 5,
	light_damage = 0,
	fear_height = 6,
	animation = {
		speed_normal = 10,	speed_run = 20,
		fly_speed = 8,		stand_speed = 8,
		stand_start = 0,	stand_end = 20,
		walk_start = 0,		walk_end = 20,
		run_start = 0,		run_end = 20,
	},
	blood_amount = 0,
})



-- if minetest.get_modpath("ethereal") then

--	mobs:spawn({
--		name = "mobs_animal:panda",
--		nodes = {"ethereal:bamboo_dirt"},
--		neighbors = {"group:grass"},
--		min_light = 14,
--		interval = 60,
--		chance = 8000, -- 15000
--		min_height = 10,
--		max_height = 80,
--		day_toggle = true,
--	})
-- end

mobs:register_egg("mobs_animal:MonkeyK", S("Monkey King"), "wool_green.png", 1)
mobs:register_egg("mobs_animal:MonkeyN", S("Monkey"), "wool_brown.png", 1)
mobs:register_egg("mobs_animal:MonkeyG", S("Gorilla"), "wool_brown.png", 1)
mobs:register_egg("mobs_animal:Tiger", S("Tiger"), "wool_yellow.png", 1)
mobs:register_egg("mobs_animal:Cheetah", S("Cheetah"), "wool_yellow.png", 1)
mobs:register_egg("mobs_animal:DragonA", S("Dragon A"), "wool_red.png", 1)
mobs:register_egg("mobs_animal:DragonB", S("Dragon B"), "wool_red.png", 1)

