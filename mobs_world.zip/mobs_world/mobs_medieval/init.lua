--mobs_badplayer v1.4
--maikerumine
--made for Extreme Survival game
--License for code WTFPL


local path = minetest.get_modpath("mobs_medieval")

--	nodes, weapons & arrows
dofile(path .. "/me_a_a.lua") --	arrows	--
--	dofile(path .. "/me_a_n.lua") --	nodes --
--	dofile(path .. "/me_a_w.lua") --	weapons	--

--  medieval mobs
--  dofile(path .. "/me_emp_a.lua") --
dofile(path .. "/me_emp_b.lua") -- 
dofile(path .. "/me_emp_ba.lua") --
dofile(path .. "/me_emp_bb.lua") --
dofile(path .. "/me_emp_bc.lua") --
dofile(path .. "/me_emp_bd.lua") --
--  dofile(path .. "/me_emp_c.lua") --
--  dofile(path .. "/me_emp_d.lua") --

--  evil mobs
dofile(path .. "/me_evil_dea.lua") --
dofile(path .. "/me_evil_emp.lua") --
dofile(path .. "/me_evil_gho.lua") --
dofile(path .. "/me_evil_mon.lua") --
dofile(path .. "/me_evil_ske.lua") --


print("[Mobs-World] Medieval")
print("[Mobs-World] Mobs")
print("[Mobs-World] World")
print("[Mobs-World] Loaded!")