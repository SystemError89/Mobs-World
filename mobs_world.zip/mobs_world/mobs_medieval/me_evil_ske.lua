-- Medieval Folk ( Skeletons )

--soldier drops when right click with gold lump.
mobs.npc_drops = { "default:pick_steel", "mobs:meat", "default:sword_steel", "default:shovel_steel", "farming:bread", "default:wood" }--Added 20151121
mobs.npc2_drops = { "default:pick_mese", "mobs:meat", "default:sword_diamond", "default:pick_diamond", "farming:bread", "default:wood" }--Added 20151121


-- Skeleton King

mobs:register_mob("mobs_medieval:EvilskeKing", {
	-- animal, monster, npc
	name = "EvilskeKing",
	nametag = "Skeletton King",
	type = "evil",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 7, -- shoot for 10 seconds
	dogshoot_count2_max = 8, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240,
	armor = 80,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_ske_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
--   		{"EVIL_ske_queen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 4,
	jump = true,
	jump_height = 7,
	fall_speed = -6,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	view_range = 18,
	floats = .3,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

-- Knight

mobs:register_mob("mobs_medieval:EVILskek", {
	-- animal, monster, npc
	name = "EVILskek",
	type = "evil",
	owner = "EvilskeKing",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 55,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "amcaw_hunchback.b3d",
	drawtype = "back",
	textures = {
   		{"EVIL_ske_knight1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   	{"EVIL_ske_knight5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_knight9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=2.2, y=2.2},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Troop

mobs:register_mob("mobs_medieval:EVILsket", {
	-- animal, monster, npc
	name = "EVILsket",
	type = "evil",
	owner = "EvilskeKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 36, hp_max = 46, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_ske_troop1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_troop2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_troop3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_troop4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_troop5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
-- 		{"EVIL_ske_troop6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_troop7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 4,
	view_range = 12,
	floats = .2,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Warrior

mobs:register_mob("mobs_medieval:EVILskew", {
	-- animal, monster, npc
	name = "EVILskew",
	type = "evil",
	owner = "EvilskeKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "mobs_mc_skeleton.b3d",
	textures = {
		{"EVIL_ske_war1.png"},
		{"EVIL_ske_war2.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_war3.png"},
		{"EVIL_ske_war4.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_ske_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_ske_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_war7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_war8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 3,
	fall_damage = 5,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 20,
		stand_start = 0,		stand_end = 40,
		walk_start = 40,		walk_end = 60,
		run_start = 40,			run_end = 60,
		punch_start = 70,		punch_end = 90,
		shoot_start = 70,		shoot_end = 90,
	},
})

-- Archer

mobs:register_mob("mobs_medieval:EVILskea", {
	-- animal, monster, npc
	name = "EVILskea",
	type = "evil",
	owner = "EvilskeKing",
	-- aggressive, shoots shuriken
	damage = 2,
	reach = 2,
	attack_type = "shoot",
	arrow = "mobs_medieval:arrow1",
	balistic = true,
	shoot_interval = .7,
	shoot_offset = 2,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 27, hp_max = 34,
	armor_groups= { daemonic=50, },
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_ske_arc1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   	{"EVIL_ske_arc2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_arc3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_arc4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Villager

mobs:register_mob("mobs_medieval:EVILskevil", {
	-- animal, monster, npc
	name = "EVILskevil",
	type = "evil",
	owner = "EvilskeKing",
	-- aggressive, shoots shuriken
	damage = 3,
	reach = 2,
	attack_type = "dogfight",
	shoot_interval = .5,
	shoot_offset = 2,
	attacks_npcs = true,
	attack_animals = false,
	attack_armyes = false,
	attack_tbs = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 20, hp_max = 30, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_ske_vil1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   		{"EVIL_ske_vil2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_vil3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_vil4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_vil5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   		{"EVIL_ske_vil6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_ske_vil7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	floats = 1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})



-- mobs spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_medieval:EvilskeKing", "King (Skeleton)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILskek", "Knight (Skeleton)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILsket", "Troop (Skeleton)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILskew", "Warrior (Skeleton)", "default_leaves.png", 1)
-- mobs:register_egg("mobs_medieval:EVILskea", "Archer (Skeleton)", "default_leaves.png", 1)
-- mobs:register_egg("mobs_medieval:EVILskevil", "Villager (Skeleton)", "default_leaves.png", 1)



-- fireball (weapon)
mobs:register_arrow("mobs_medieval:fireball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"mobs_fireball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "mobs_fireball.png",
	tail_size = 10,
	glow = 5,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})

-- fireball3 (weapon)
mobs:register_arrow("mobs_medieval:fireball3", {
	visual = "sprite",
	visual_size = {x = 0.7, y = 0.7},
	textures = {"mobs_fireball3.png"},
	velocity = 7,
	tail = 1,
	tail_texture = "mobs_fireball3.png",
	tail_size = 10,
	glow = 6,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 14},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 20},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})