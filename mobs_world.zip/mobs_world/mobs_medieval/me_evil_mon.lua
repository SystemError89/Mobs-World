-- Medieval Folk ( Team Evil - Monsters )

--soldier drops when right click with gold lump.
mobs.npc_drops = { "default:pick_steel", "mobs:meat", "default:sword_steel", "default:shovel_steel", "farming:bread", "default:wood" }--Added 20151121
mobs.npc2_drops = { "default:pick_mese", "mobs:meat", "default:sword_diamond", "default:pick_diamond", "farming:bread", "default:wood" }--Added 20151121


-- Monster King

mobs:register_mob("mobs_medieval:MonsterKing", {
	-- animal, monster, npc
	name = "MonsterKing",
	nametag = "Monster King",
	type = "evil", "monster",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 4, -- shoot for 10 seconds
	dogshoot_count2_max = 11, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240,
	armor = 75,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_mon_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
   		{"EVIL_mon_queen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 3,
	jump = true,
	jump_height = 3,
	fall_speed = -7,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	view_range = 18,
	floats = 2.5,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

-- Officer

mobs:register_mob("mobs_medieval:EVILmonofi", {
	-- animal, monster, npc
	name = "EVILmonofi",
	type = "evil", "monster",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 2, -- shoot for 10 seconds
	dogshoot_count2_max = 13, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = 1.8,
	arrow = "mobs_medieval:fireball",
	shoot_offset = 1,
	atacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 36, hp_max = 47,
	armor_groups = {fleshy = 80,	daemon = 20},
	-- textures and model
	collisionbox = {-0.5, -0.01, -0.5, 0.5, 1.7, 0.5},
	visual = "mesh",
	mesh = "amcaw_oldlady.b3d",
	rotate = 180,
	textures = {
		{"EVIL_mon_ofi1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_ofi2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_ofi3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_ofi4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_ofi5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=4, y=4},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 2,
	view_range = 20,
	floats = 1.6,
	-- model animation
	animation = {
		speed_normal = 25,		speed_run = 30,
		stand_start = 40,		stand_end = 80,
		walk_start = 0,			walk_end = 40,
		run_start = 0,			run_end = 40,
		punch_start = 168,		punch_end = 188,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Armored Monster

mobs:register_mob("mobs_medieval:EVILmonknight", {
	-- animal, monster, npc
	name = "EVILmonknight",
	type = "evil", "monster",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 75,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_mon_knight1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_knight2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_knight3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_knight4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   	{"EVIL_mon_knight5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_knight6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Archer

mobs:register_mob("mobs_medieval:EVILmonarc", {
	-- animal, monster, npc
	name = "EVILmonarc",
	type = "evil",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 2,
	reach = 2,
	attack_type = "shoot",
	arrow = "mobs_medieval:arrow1",
	balistic = true,
	shoot_interval = .7,
	shoot_offset = 2,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 27, hp_max = 34,
	armor_groups= { daemonic=50, },
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_mon_arc1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--   	{"EVIL_mon_arc2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_arc3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_arc4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 16,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	-----	-----	-----	-----	-----	-----	-----	-----	-----	-----
--	Monster (slim)

mobs:register_mob("mobs_medieval:EVILmonA", {
	-- animal, monster, npc
	name = "EVILmonA",
	type = "evil", "monster",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 5,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	-- health & armor
	hp_min = 24, hp_max = 40, armor = 95,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "evil_mon_giant.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_mon_giant.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
-- 		{"EVIL_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=.9, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Monster (not so slim)

mobs:register_mob("mobs_medieval:EVILmonB", {
	-- animal, monster, npc
	name = "EVILmonB",
	type = "evil", "monster",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_animals = true,
	attack_npcs = true,
	attack_players = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "amcaw_lawyer.b3d",
	rotate = 180,
	textures = {
		{"EVIL_mon_JB2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
-- 		{"EVIL_war6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_war8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=4, y=4},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	floats = 1.3,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Monster (long)

mobs:register_mob("mobs_medieval:EVILmonC", {
	-- animal, monster, npc
	name = "EVILmonC",
	type = "evil", "monster",
	owner = "MonsterKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_animals = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = true,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "mobs_dild_monster.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_sle1.png"},
		{"EVIL_sle2.png"},
		{"EVIL_sle3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_sle4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_sle5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
 		{"EVIL_sle6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_sle8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_sle9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=1.3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 2,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	-----	-----	-----	-----	-----	-----	-----	-----	-----	-----

-- Bim Bear King

mobs:register_mob("mobs_medieval:EVILbbKing", {
	-- animal, monster, npc
	name = "EVILbbKing",
	nametag = "Bim Bear King",
	type = "evil", "monster",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 3, -- shoot for 10 seconds
	dogshoot_count2_max = 12, -- dogfight for 3 seconds
	reach = 4,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 100, hp_max = 120,
	armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_mon_BBking1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
--   		{"EVIL_mon_BBqueen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=2, y=2},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 3,
	jump = true,
	jump_height = 3,
	fall_speed = -7,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	view_range = 18,
	floats = 1.4,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

-- Bim Bear

mobs:register_mob("mobs_medieval:EVILmonBB", {
	-- animal, monster, npc
	name = "EVILmonBB",
	type = "evil", "monster",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 38, hp_max = 46, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_mon_BB1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"EVIL_mon_BB5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB7.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	   	{"EVIL_mon_BB8.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB9.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB10.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_BB11.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	-----	-----	-----	-----	-----	-----	-----	-----	-----	-----

--	Jungle Beast

mobs:register_mob("mobs_medieval:EVILmonJB", {
	-- animal, monster, npc
	name = "EVILmonJB",
	type = "evil", "monster",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 56, armor = 85,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_mon_JB1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_JB2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_JB3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_mon_JB4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	-----	-----	-----	-----	-----	-----	-----	-----	-----	-----

--	Water Beast

mobs:register_mob("mobs_medieval:EVILmonWB", {
	-- animal, monster, npc
	name = "EVILmonWB",
	type = "evil", "monster",
	-- aggressive, shoots shuriken
	damage = 10,
	attack_type = "dogfight",
	attack_animals = true,
	attacks_npcs = true,
	attack_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = true,
	peaceful = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 28, hp_max = 36, armor = 55,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
   		{"EVIL_mon_WB1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_WB2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_WB3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_WB4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_WB5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
		{"EVIL_mon_WB6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1.1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 3,
	jump = true,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 3,
	view_range = 10,
	floats = .1,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

--	-----	-----	-----	-----	-----	-----	-----	-----	-----	-----


-- mobs spawn on top of trees
--mobs:register_spawn("mobs_medieval:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

mobs:register_egg("mobs_medieval:MonsterKing", "Monster King (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonofi", "Big Monster (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonknight", "Armored Monster (Evil)", "default_leaves.png", 1)
-- mobs:register_egg("mobs_medieval:EVILmonarc", "Archer (Monster)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonA", "Slim Monster (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonB", "Nss Monster (Evil)", "default_leaves.png", 1)
-- mobs:register_egg("mobs_medieval:EVILmonC", "Long Monster (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILbbKing", "Bim Bear King (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonBB", "Bim Bear (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonJB", "Jungle Monster (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILmonWB", "Water Monster (Evil)", "default_leaves.png", 1)



-- fireball (weapon)
mobs:register_arrow("mobs_medieval:fireball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"mobs_fireball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "mobs_fireball.png",
	tail_size = 10,
	glow = 5,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})

-- fireball3 (weapon)
mobs:register_arrow("mobs_medieval:fireball3", {
	visual = "sprite",
	visual_size = {x = 0.7, y = 0.7},
	textures = {"mobs_fireball3.png"},
	velocity = 7,
	tail = 1,
	tail_texture = "mobs_fireball3.png",
	tail_size = 10,
	glow = 6,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 14},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 20},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})