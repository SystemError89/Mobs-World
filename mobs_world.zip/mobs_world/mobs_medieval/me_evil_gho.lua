-- Medieval Folk ( Evil Kingdom - Ghosts )

--soldier drops when right click with gold lump.
mobs.npc_drops = { "default:pick_steel", "mobs:meat", "default:sword_steel", "default:shovel_steel", "farming:bread", "default:wood" }--Added 20151121
mobs.npc2_drops = { "default:pick_mese", "mobs:meat", "default:sword_diamond", "default:pick_diamond", "farming:bread", "default:wood" }--Added 20151121


-- Ghost King

mobs:register_mob("mobs_medieval:EvilghoKing", {
	-- animal, monster, npc
	name = "EvilghoKing",
	nametag = "Ghost King",
	type = "evil",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 5, -- shoot for 10 seconds
	dogshoot_count2_max = 10, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = .8,
	arrow = "mobs_medieval:fireball3",
	shoot_offset = 2,
	attacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	passive = false,
	pathfinding = true,
	-- health & armor
	hp_min = 200, hp_max = 240,
	armor = 70,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_gho_king1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
--   		{"EVIL_gho_queen1.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_mese"].inventory_image,},
	},
	visual_size = {x=1, y=1},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 2,
	run_velocity = 3,
	jump = true,
	jump_height = 2,
	fall_speed = -5,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 1,
	floats = .2,
	view_range = 18,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
	immune_to = {
		{"default:sword_wood", 0}, -- no damage
		{"default:sword_steel", 0}, -- no damage
		{"default:sword_stone", 0}, -- no damage
		{"default:gold_lump", -10}, -- heals by 10 points
	},
})

local create_enderman_textures = function(block_type, itemstring)
	local base = {
					{"EVIL_gho_long3.png"},
					{"EVIL_gho_long2.png"},
					{"EVIL_gho_long1.png"},
			}

	--[[ Order of the textures in the texture table:
		Flower, 90 degrees
		Flower, 45 degrees
		Held block, backside
		Held block, bottom
		Held block, front
		Held block, left
		Held block, right
		Held block, top
		Enderman texture (base)
	]]
	-- Regular cube
	if block_type == "cube" then
		local tiles = minetest.registered_nodes[itemstring].tiles
		local textures = {}
		local last
		if mobs_mc.enderman_block_texture_overrides[itemstring] then
			-- Texture override available? Use these instead!
			textures = mobs_mc.enderman_block_texture_overrides[itemstring]
		else
			-- Extract the texture names
			for i = 1, 6 do
				if type(tiles[i]) == "string" then
					last = tiles[i]
				elseif type(tiles[i]) == "table" then
					if tiles[i].name then
						last = tiles[i].name
					end
				end
				table.insert(textures, last)
			end
		end
		return {
			"blank.png",
			"blank.png",
			textures[5],
			textures[2],
			textures[6],
			textures[3],
			textures[4],
			textures[1],
			base, -- Enderman texture
		}
	-- Node of plantlike drawtype, 45° (recommended)
	elseif block_type == "plantlike45" then
		local textures = minetest.registered_nodes[itemstring].tiles
		return {
			"blank.png",
			textures[1],
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base,
		}
	-- Node of plantlike drawtype, 90°
	elseif block_type == "plantlike90" then
		local textures = minetest.registered_nodes[itemstring].tiles
		return {
			textures[1],
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base,
		}
	elseif block_type == "unknown" then
		return {
			"blank.png",
			"blank.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			"unknown_node.png",
			base, -- Enderman texture
		}
	-- No block held (for initial texture)
	elseif block_type == "nothing" or block_type == nil then
		return {
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			"blank.png",
			base, -- Enderman texture
		}
	end
end

-- Hardcore Ghost

mobs:register_mob("mobs_medieval:EVILghohc", {
	-- animal, monster, npc
	name = "EVILghohc",
	type = "evil",
	owner = "EvilghoKing",
	-- aggressive, shoots shuriken
	damage = 12,
	attack_type = "dogshoot",
	dogshoot_switch = 1,
	dogshoot_count_max = 4, -- shoot for 10 seconds
	dogshoot_count2_max = 11, -- dogfight for 3 seconds
	reach = 3,
	shoot_interval = 1.8,
	arrow = "mobs_medieval:fireball",
	shoot_offset = 1,
	atacks_npcs = true,
	attacks_players = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_armyes = true,
	attacks_tes = true,
	attack_evils = false,
	group_attack = false,
	passive = false,
	pathfinding = true,
	stepheight = 1.2,
	-- health & armor
	hp_min = 36, hp_max = 47,
	armor = 75,
	-- textures and model
	collisionbox = {-0.3, -0.01, -0.3, 0.3, 2.89, 0.3},
	visual = "mesh",
	mesh = "mobs_enderman.b3d",
	textures = create_enderman_textures(),
	visual_size = {x=3, y=3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 3,
	run_velocity = 3,
	fly = true,
	fly_in = "air",
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 2,
	view_range = 20,
	floats = .6,
	-- model animation
	animation = {
		speed_normal = 30,		speed_run = 30,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Walking Ghost

mobs:register_mob("mobs_medieval:EVILgeist", {
	-- animal, monster, npc
	name = "EVILgeist",
	type = "evil",
	owner = "EvilghoKing",
	-- aggressive, shoots shuriken
	damage = 7,
	reach = 2,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybs = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attacks_tbs = true,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 36, hp_max = 48, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "3d_armor_character.b3d",
	drawtype = "front",
	textures = {
		{"EVIL_gho_geist1.png",	"3d_armor_trans.png",},
--		{"EVIL_gho_geist2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_geist3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_geist4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_geist5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=.9},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 1,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 4,
	view_range = 12,
	floats = .2,
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 20,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})

-- Flying Ghost

mobs:register_mob("mobs_medieval:EVILghost", {
	-- animal, monster, npc
	name = "EVILghost",
	type = "evil", "monster",
	owner = "EvilghoKing",
	-- aggressive, shoots shuriken
	damage = 6,
	reach = 3,
	attack_type = "dogfight",
	attack_npcs = true,
	attack_players = true,
	attack_armybas = true,
	attack_armybbs = true,
	attack_armybcs = true,
	attack_armybds = false,
	attack_armyas = true,
	attacks_tas = true,
	attack_armycs = true,
	attacks_tcs = true,
	attack_armyds = true,
	attacks_tds = true,
	attack_evils = false,
	group_attack = false,
	peaceful = false,
	passive = false,
	-- health & armor
	hp_min = 26, hp_max = 36, armor = 100,
	-- textures and model
	collisionbox = {-0.35,-1.0,-0.35, 0.35,0.8,0.35},
	visual = "mesh",
	mesh = "mobs_ghost_ghost.x",
	drawtype = "front",
	textures = {
		{"EVIL_gho_ghost1.png"},
--		{"EVIL_gho_ghost2.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_ghost3.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_ghost4.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
--		{"EVIL_gho_sle5.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
-- 		{"EVIL_gho_sle6.png",	"3d_armor_trans.png",	minetest.registered_items["default:sword_steel"].inventory_image,},
	},
	visual_size = {x=1, y=1.3},
	-- sounds
	makes_footstep_sound = true,
	sounds = {},
	-- speed and jump
	walk_velocity = 1,
	run_velocity = 1,
	-- drops shuriken when dead
	drops = {
		{name = "default:apple",
		chance = 1, min = 1, max = 5},
	},
	-- damaged by
	water_damage = 0,
	lava_damage = 2,
	light_damage = 0,
	fall_damage = 0,
	view_range = 12,
	floats = .7,
	fly = true,
	fly_in = "air",
	-- model animation
	animation = {
		speed_normal = 10,		speed_run = 10,
		stand_start = 0,		stand_end = 79,
		walk_start = 168,		walk_end = 187,
		run_start = 168,		run_end = 187,
		punch_start = 200,		punch_end = 219,
		shoot_start = 200,		shoot_end = 219,
	},
})



-- mobs spawn on top of trees
--mobs:register_spawn("testmobs:ninja", {"default:leaves"}, 5, 0, 10000, 1, 31000)

--  mobs:register_egg("mobs_medieval:EvilghoKing", "Ghost King (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILghohc", "Hardcore Ghost (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILgeist", "Geist (Evil)", "default_leaves.png", 1)
mobs:register_egg("mobs_medieval:EVILghost", "Ghost (Evil)", "default_leaves.png", 1)



-- fireball (weapon)
mobs:register_arrow("mobs_medieval:fireball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"mobs_fireball.png"},
	velocity = 6,
	tail = 1,
	tail_texture = "mobs_fireball.png",
	tail_size = 10,
	glow = 5,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 8},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})

-- fireball3 (weapon)
mobs:register_arrow("mobs_medieval:fireball3", {
	visual = "sprite",
	visual_size = {x = 0.7, y = 0.7},
	textures = {"mobs_fireball3.png"},
	velocity = 7,
	tail = 1,
	tail_texture = "mobs_fireball3.png",
	tail_size = 10,
	glow = 6,
	expire = 0.1,

	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 14},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 20},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 1)
	end
})