--	----	------- Territorial Nodes -------	----	--


--	---- New Time ----	--


--	nTA Soldier-Spawn	--

minetest.register_node("mobs_modern:ntas", {
	description = "nTA Soldier-Spawner",
	tiles = {"me_nTAdirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})


--	nTB Soldier-Spawn	--

minetest.register_node("mobs_modern:ntbs", {
	description = "nTB Soldier-Spawner",
	tiles = {"me_nTBdirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})


--	nTC Soldier-Spawn	--

minetest.register_node("mobs_modern:ntcs", {
	description = "nTC Soldier-Spawner",
	tiles = {"me_dirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})


--	nTD Soldier-Spawn	--

minetest.register_node("mobs_modern:ntds", {
	description = "nTD Soldier-Spawner",
	tiles = {"default_grass.png", "default_dirt.png",
		{name = "default_dirt.png^default_grass_side.png",
			tileable_vertical = false}},
	groups = {oddly_breakable_by_hand = 1, soil = 1, spreading_dirt_type = 1, falling_node = 1},
	drop = 'default:dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name = "default_grass_footstep", gain = 0.25},
	}),
})


--	nTE Soldier-Spawn	--

minetest.register_node("mobs_modern:ntes", {
	description = "nTE Soldier-Spawner",
	tiles = {"default_dirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})


--	nTF Soldier-Spawn	--

minetest.register_node("mobs_modern:ntfs", {
	description = "nTF Soldier-Spawner",
	tiles = {"me_dirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})


--	nTT Soldier-Spawn	--

minetest.register_node("mobs_modern:ntts", {
	description = "Terrorist-Spawner",
	tiles = {"me_dirt.png"},
	groups = {crumbly = 3, soil = 1, oddly_breakable_by_hand = 2},
	sounds = default.node_sound_dirt_defaults(),
})